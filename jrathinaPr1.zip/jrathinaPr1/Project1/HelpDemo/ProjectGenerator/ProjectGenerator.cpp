///////////////////////////////////////////////////////////////////////
//  ProjectGenerator.cpp- generates visual studio project with all   //
//  the files in test folder                                         //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////


#include "ProjectGenerator.h"


//function for generating the visual studio project
void ProjectGenerator::writeFilesInXml(const std::string& path, const std::string& testname  , std::vector<std::string> testFolderFilesList) {
  std::vector<std::string> headerFileList,cppFileList;
  int checker;
  for(size_t i=0;i<testFolderFilesList.size();i++)
  {
    checker = testFolderFilesList[i].find(".h");
    if(checker>=0)
      headerFileList.push_back(testFolderFilesList[i]);
    else
      cppFileList.push_back(testFolderFilesList[i]);
  }
  std::string search_string1 = "Includeyourfileshere1";  //cpp file
  std::string search_string2 = "Includeyourfileshere2";  //header file
  std::string replace_string1 = "";
  std::string replace_string2 = "";
  for(size_t i=0;i<cppFileList.size();i++)
    replace_string1+= "<ClCompile Include=\"" + cppFileList[i]   +"\" />";
  for(size_t i=0;i<headerFileList.size();i++)
    replace_string2+= "<ClInclude Include=\"" + headerFileList[i]   +"\" />";
  std::string inbuf;
  std::ofstream myfile;
  std::string testFolderPath = path + "\\" + testname + ".vcxproj";   //setting path of the test folder to place the visual studio project file
  myfile.open (testFolderPath);     //replacing placeholder in template vscproj file with the include files list
  std::fstream stream("../HelpDemo\\Template_VCXPROJ.vcxproj",std::ios::in);
  while(!stream.eof()) {
      getline(stream, inbuf);
      int spot1 = inbuf.find(search_string1);
      int spot2 = inbuf.find(search_string2);
      if(spot1 >= 0)                //searching for header file placemark
      {
         std::string tmpstring = inbuf.substr(0,spot1);
         tmpstring += replace_string1;
         tmpstring += inbuf.substr(spot1+search_string1.length(), inbuf.length());
         inbuf = tmpstring;
         myfile << inbuf;
      }
      else if(spot2 >= 0)           //searching for cpp file placemark
      {
         std::string tmpstring = inbuf.substr(0,spot2);
         tmpstring += replace_string2;
         tmpstring += inbuf.substr(spot2+search_string2.length(), inbuf.length());
         inbuf = tmpstring;
         myfile << inbuf;
      }
      else
        myfile << inbuf <<"\n";
  }
  stream.close();
  myfile.close();
}




//<----------------------- test stub -------------------------------------------------------

#ifdef TEST_PROJ_GEN

int main()
{
  ProjectGenerator pg;
  std::vector<std::string> filesList;
  filesList.resize(2);
  filesList[0]="demo1.cpp";
  filesList[1]="demo1.h";
  pg.writeFilesInXml("C:\\", "DemoTest",filesList);
  return 0;
}

#endif