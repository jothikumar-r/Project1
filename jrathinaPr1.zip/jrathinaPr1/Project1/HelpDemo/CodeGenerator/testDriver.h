#include "ITesh.h"
#include "dataGenerator.h"
#include "dataLogger.h"

//include

class XXX : public ITest
{
public:
	bool test();
	ITest* create();
};