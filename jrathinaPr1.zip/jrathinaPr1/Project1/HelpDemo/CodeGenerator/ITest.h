#ifndef I_TEST
#define I_TEST

struct ITest 
{
  virtual bool test()=0;
  static ITest* Create();
};

#endif
