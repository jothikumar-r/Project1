#ifndef CODE_GENERATOR_H
#define CODE_GENERATOR_H

///////////////////////////////////////////////////////////////////////
//  CodeGenerator.h  -   Includes parent(root) file in the test      //
//  driver and places the file in test folder                        //
//  wizard                                                           //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    After finding the root, it has to be included in the test driver
    and the test driver is renamed to <testname>testdriver. 


    Public Interface:
    -----------------
      codeGenerator cg;                                                 creating object of codeGenerator class
      cg.fileGenerator("../../../Testfolder","littleboy",rootFiles);    calling filegenerator to generate the test driver packager

*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /EHa /DTEST_CODEGENERATOR CodeGenerator.cpp           //
//                                                           //
//  Files Required:                                          //
//    CodeGenerator.h,CodeGenerator.cpp                      //
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/



#include <string>
#include <vector>

class codeGenerator
{
public:
  void fileGenerator(const std::string&, const std::string&, std::vector<std::string>);

private:
  void rootFileListIncluder(std::vector<std::string> testFolderFilePath, std::vector<std::string> rootFiles, const std::string& testName, const std::string& path);
};


#endif