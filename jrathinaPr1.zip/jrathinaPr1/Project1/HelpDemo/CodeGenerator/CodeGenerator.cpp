///////////////////////////////////////////////////////////////////////
//  CodeGenerator.cpp -  Includes parent(root) file in the test      //
//  driver and places the file in test folder                        //
//  wizard                                                           //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////

#include "CodeGenerator.h"
#include <fstream>
#include <string>

//function generates files such as test driver.h and test driver.cpp
void codeGenerator::fileGenerator(const std::string& path, const std::string& testName, std::vector<std::string> rootFiles)
{
  std::string search_string = "XXX";
  std::string replace_string = testName + "TestDriver";
  std::string inbuf;
  std::ofstream myfile;
  std::vector<std::string> localFileName;
  localFileName.push_back("testDriver.h");
  localFileName.push_back("testDriver.cpp");
  std::vector<std::string> testFolderFilePath;
  testFolderFilePath.push_back(path + "\\" + replace_string + "1.h");
  testFolderFilePath.push_back(path + "\\" + replace_string + ".cpp");

  for(int i=0;i<2;i++)                                                        //creating two files
  {
    myfile.open (testFolderFilePath[i]);
    std::fstream stream("../HelpDemo\\" + localFileName[i],std::ios::in);
    while(!stream.eof())
    {
        getline(stream, inbuf);
        int spot = inbuf.find(search_string);
        if(spot >= 0)                                                              //finding the spot to replace and replacing it with the replace string
        {
           std::string tmpstring = inbuf.substr(0,spot);
           tmpstring += replace_string;
           tmpstring += inbuf.substr(spot+search_string.length(), inbuf.length());
           inbuf = tmpstring;
           myfile << inbuf <<"\n";
        }
        else
        {
          myfile << inbuf;
          myfile <<"\n";
        }
    }
    stream.close();
    myfile.close();
  }
  rootFileListIncluder(testFolderFilePath, rootFiles, testName, path);      //calling this function to complete the code generator process
}

//helper function which will complete generating test driver header and cpp file
void codeGenerator::rootFileListIncluder(std::vector<std::string> testFolderFilePath, std::vector<std::string> rootFiles, const std::string& testName, const std::string& path)
{
  std::string search_string = "//include";
  std::vector<std::string> includeRootList;

  if(rootFiles.size()==0)
  {
    includeRootList.resize(1);
    includeRootList[0]="";
  }

  for(size_t i=0;i<rootFiles.size();i++)
    includeRootList.push_back("#include \"" + rootFiles[i] + "\"");

  std::string replace_string = testName + "TestDriver";       //replacing the testdriver template name with TestnameTestDriver
  std::string inbuf;
  std::ofstream myfile;
  
    myfile.open (path + "\\" + replace_string + ".h");
    std::fstream stream(testFolderFilePath[0],std::ios::in);
    while(!stream.eof())
    {
        getline(stream, inbuf);
        int spot = inbuf.find(search_string);                 //finding the spot to replace and replacing it with the replace string
        if(spot >= 0)
        {
           std::string tmpstring = inbuf.substr(0,spot);
           tmpstring += includeRootList[0];
           tmpstring += inbuf.substr(spot+search_string.length(), inbuf.length());
           inbuf = tmpstring + "\n";
           myfile << inbuf;
           for(size_t i=1;i<includeRootList.size();i++)
           {
             inbuf = includeRootList[i];
             myfile << inbuf;
             myfile <<"\n";
           }
        }
        else
        {
          myfile << inbuf;
          myfile <<"\n";
        }
    }
    stream.close();
    myfile.close();
    remove(testFolderFilePath[0].c_str());
}



//<------------------test stub-----------------------------

#ifdef TEST_CODEGENERATOR

#include <iostream>
#include <vector>
#include <string>

int main()
{
  std::vector<std::string> rootFiles;
  rootFiles.push_back("sampleA.h");
  rootFiles.push_back("sampleB.h");

  std::cout<<"\nChecking Code Generator\n";
  codeGenerator cg;
  cg.fileGenerator("../../../Testfolder","littleboy",rootFiles);
}

#endif