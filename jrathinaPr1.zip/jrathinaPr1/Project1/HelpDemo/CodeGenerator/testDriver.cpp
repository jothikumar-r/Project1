#include "testDriver.h"

bool XXX::test()
{
	return true;
}

ITest* XXX::create()
{
	return new XXX;	
}
