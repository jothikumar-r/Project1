#pragma once
// ITestGenerator.h
//
// Jothikumar Rathinamoorthy

#ifdef TEST_EXPORTS
#define TEST_API __declspec(dllexport)
#else
#define TEST_API __declspec(dllimport)
#endif

#include <vector>
#include <string>

class TEST_API ITestGenerator
{
public:
  virtual ~ITestGenerator(void) {}
  static ITestGenerator* createTest();
  virtual std::vector<std::string> getInput()=0;
};
