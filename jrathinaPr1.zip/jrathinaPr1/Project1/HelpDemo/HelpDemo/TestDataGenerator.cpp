#include "XXX.h"

TestDataGenerator::TestDataGenerator(void)
{

}

TestDataGenerator::~TestDataGenerator(void)
{

}

ITestGenerator* ITestGenerator::createTest()
{
  return new TestDataGenerator;
}

std::vector<std::string> TestDataGenerator::getInput()
{
  std::vector<std::string> input;

  return input;
}
