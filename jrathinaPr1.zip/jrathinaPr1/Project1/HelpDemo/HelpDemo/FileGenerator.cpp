///////////////////////////////////////////////////////////////////////
//  FileGenerator.cpp-  generates test data generator and test logger//
//  in test folder                                                   //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////


#include "FileGenerator.h"

//function for copying files to the test folder path
void FileGenerator::copyFiles(const std::string& path, std::vector<std::string> copyFilesList)
 {
    std::string inbuf;
    std::ofstream myfile;
    copyFilesList.push_back("main.cpp");
    for(size_t i=0;i<copyFilesList.size();i++)
    {
      std::string path1 = path + "\\" + copyFilesList[i];
      myfile.open (path1);
      std::fstream stream("../HelpDemo\\" + copyFilesList[i],std::ios::in);
      while(!stream.eof())
      {
          getline(stream, inbuf);
          myfile << inbuf;
          myfile <<"\n";
      }
      stream.close();
      myfile.close();
    }
 }

//generatin the testdatagenerator and testlogger in the testfolder
 void FileGenerator::datagenLogFileGenerator(const std::string& path, const std::string& testName)
{
  std::string search_string = "XXX";
  std::string inbuf;
  std::ofstream myfile;

  std::vector<std::string> localFileName;
  localFileName.push_back("TestDataGenerator.h");
  localFileName.push_back("TestDataGenerator.cpp");
  localFileName.push_back("TestLogger.h");
  localFileName.push_back("TestLogger.cpp");

  std::vector<std::string> replace_string;
  replace_string.push_back(testName + "TestDataGenerator");
  replace_string.push_back(testName + "TestDataGenerator");
  replace_string.push_back(testName + "TestLogger");
  replace_string.push_back(testName + "TestLogger");
  
  for(int i=0;i<4;i++)                                                          //writing files in the test folder
  {
    myfile.open (path + "\\" + testName + localFileName[i]);
    std::fstream stream("../HelpDemo\\" + localFileName[i],std::ios::in);
    while(!stream.eof())
    {
        getline(stream, inbuf);
        int spot = inbuf.find(search_string);
        if(spot >= 0)
        {
           std::string tmpstring = inbuf.substr(0,spot);
           tmpstring += replace_string[i];
           tmpstring += inbuf.substr(spot+search_string.length(), inbuf.length());
           inbuf = tmpstring;
           myfile << inbuf <<"\n";
        }
        else
        {
          myfile << inbuf;
          myfile <<"\n";
        }
    }
    stream.close();
    myfile.close();
  }
}

//<--------------------test stub------------------------

#ifdef TEST_FILE_GEN

#include <iostream>

int main()
{
  
  std::cout<<"Demonstrating File Generator"<<std::endl;
  std::cout<<"============================"<<std::endl;

  std::vector<std::string> m_copyFilesList;
  m_copyFilesList.resize(2);
  m_copyFilesList[0] = "ITest.h";
  m_copyFilesList[1] = "ITestGenerator.h";

  FileGenerator fg;
  fg.copyFiles("C:\\", m_copyFilesList);

  std::cout<<"The files "<<m_copyFilesList[0]<<" and "<<m_copyFilesList[1]<<" in this project path are moved to the path C:\\";

  return 0;
}


#endif