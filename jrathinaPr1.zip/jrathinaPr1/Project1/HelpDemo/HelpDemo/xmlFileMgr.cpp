///////////////////////////////////////////////////////////////////////
//  xmlFileMgr.cpp-   Finds the presence of xml file, finds the test //
//  name and the name of the test files                              //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////

#include "xmlFileMgr.h"

//checking for the existence of the xml file
bool xmlFileMgr::fileExists(const std::string& path, const std::string& xmlFileName)
{
  std::string xmlPath = path + "/" + xmlFileName;
  std::ifstream ifile(xmlPath);
  return (ifile!=0);
}


//finding the list of files included in the xml file
std::vector<std::string> xmlFileMgr::FindFiles(const std::string& path, const std::string& xmlFileName)
{
  std::string xmlFilePath = path + "/" + xmlFileName;
  std::string line;
  std::string completeLine;
  completeLine = "";
  line = "";
  std::ifstream myfile (xmlFilePath);
  if (myfile.is_open())                           //reading the file and getting the test files list
  {
    while (myfile.good())
    {
      std::getline (myfile,line);
      completeLine = completeLine + line;
    }
    myfile.close();
    XmlReader rdr(completeLine);

    while(rdr.next())
    {
    if(rdr.tag() == "test_file")
      filesInXml.push_back(rdr.body());
    }
  }
  else 
    std::cout << "Unable to open the XML file"; 
  return filesInXml;
}


//function for finding the test name inside the xml
std::string xmlFileMgr::FindTestName(const std::string& path, const std::string& xmlFileName)
{
  std::string xmlFilePath = path + "/" + xmlFileName;
  std::string line;
  std::string completeLine;
  completeLine = "";
  line = "";
  std::ifstream myfile (xmlFilePath);
  if (myfile.is_open())                             //reading the xml file and finding the test name 
  {
    while (myfile.good())
    {
      std::getline (myfile,line);
      completeLine = completeLine + line;
    }
    myfile.close();
    XmlReader rdr(completeLine);

    while(rdr.next())
    {
    if(rdr.tag() == "testname")
      testName = rdr.body();
    }
  }
  else 
  {
    std::cout << "\nXML file not exists"; 
    testName="TestHarnessWizard";
  }
  return testName;
}

//<------------------------------------ test stub -------------------------------------------------

#ifdef TEST_XML_FILEMGR

#include <iostream>
#include <vector>

int main()
{
  
  std::cout<<"\nDemonstrating XML File Manager :";
  std::cout<<"\n================================";

  std::string path="..//..//..//testfolder";
  std::string xmlFileName = "test.xml";
  std::vector<std::string> testFiles;
  bool fileExistFlg = false;
  std::string testName;

  xmlFileMgr xmlFm;
  fileExistFlg = xmlFm.fileExists(path,xmlFileName);
  testFiles = xmlFm.FindFiles(path,xmlFileName);
  testName = xmlFm.FindTestName(path,xmlFileName);

  if(fileExistFlg)
  {
    std::cout<<"\nTest Name = "<<testName;

    std::cout<<"\n\n\nFiles in XML: \n";
    for(int i=0;i<testFiles.size();i++)
      std::cout<<testFiles[i]<<std::endl;
  }
  else
    std::cout<<"\nXML file not exists in the specified path";

  return 0;
}

#endif