///////////////////////////////////////////////////////////////////////
//  ExecHelper.cpp- Helps the Executive file by finding the list of  //
//  test files and supplying input to codeGenerator and fileGenerator//
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////


#include "ExecHelper.h"

//function for supplying the name of the files to create the Visual Studio Project
void ExecHelper::projectGenerator(std::string folderpath, std::string testName, std::vector<std::string> testIncludeFiles)
{
  std::vector<std::string> projIncludeFiles;
  
  for(size_t i=0;i<testIncludeFiles.size();i++)
    projIncludeFiles.push_back(testIncludeFiles[i]);

  projIncludeFiles.push_back("ITest.h");
  projIncludeFiles.push_back("ITestGenerator.h");
  projIncludeFiles.push_back("ITestLogger.h");
  projIncludeFiles.push_back(testName + "TestDriver.h");
  projIncludeFiles.push_back(testName + "TestDriver.cpp");
  projIncludeFiles.push_back(testName + "TestDataGenerator.h");
  projIncludeFiles.push_back(testName + "TestDataGenerator.cpp");
  projIncludeFiles.push_back(testName + "TestLogger.h");
  projIncludeFiles.push_back(testName + "TestLogger.cpp");
  projIncludeFiles.push_back("main.cpp");

  ProjectGenerator pg;
  pg.writeFilesInXml(folderpath,testName,projIncludeFiles);                      //generating the visual studio project
}

//function for supplying the name of the files to generate the files inside the test folder
void ExecHelper::fileGenerator(std::string folderpath, std::string testName)
{
  std::vector<std::string> copyFilesList;
  copyFilesList.push_back("ITest.h");
  copyFilesList.push_back("ITestGenerator.h");
  copyFilesList.push_back("ITestLogger.h");
    
  FileGenerator fg;
  fg.copyFiles(folderpath,copyFilesList);                                       //copy files in the test folder
  fg.datagenLogFileGenerator(folderpath, testName);                             //generating test data generator and test logger
}


//function for finding files in the xml and analyzing it in the test folder
std::vector<std::string> ExecHelper::testFilesFinder(std::string folderpath,std::string xmlFileName,std::vector<std::string> files)
{
  xmlFileMgr xmlFM;
  std::vector<std::string> xmlTestFiles, testIncludeFiles, missingFiles;
  std::string testName;
  bool fileExistFlg;
  
  if(xmlFM.fileExists(folderpath,xmlFileName))                          //checking for the presence of xml file
  {
    xmlTestFiles = xmlFM.FindFiles(folderpath,xmlFileName);
    testName = xmlFM.FindTestName(folderpath,xmlFileName);

    std::cout << "\n\n  Finding Test Files in XML: "<<std::endl;
      
    for(size_t i=0;i<xmlTestFiles.size();i++)                           //checking whether files in xml are present in the test folder
    {
      fileExistFlg = false;
      for(size_t j=0;j<files.size();j++)
      {
        if(xmlTestFiles[i] == files[j])
          fileExistFlg = true;
      }
      std::cout<<"\n  "<<xmlTestFiles[i]; 
      if(fileExistFlg == false)
        missingFiles.push_back(xmlTestFiles[i]);
    }

    if(missingFiles.size()>0)                                     //priting error and closing program if some file in xml is not found in test folder
    {
      std::cout<<"\n\nAll the test files in XML configuration file are not present in the test folder !"<<std::endl;
      exit(0);
    }
    testIncludeFiles = xmlTestFiles;
  }
  else if(xmlTestFiles.size() == 0)
    testIncludeFiles = files;
  return testIncludeFiles;
}

//<------------------------------------ test stub -------------------------------------------------

#ifdef TEST_EXEC_HELPER

#include <iostream>
#include <vector>

int main()
{
  
  std::cout<<"Demonstrating Execution Helper\n";
  std::cout<<"==============================\n";
  
  ExecHelper eh;
  std::string folderpath="..//..//testfolder";
  std::string testName="littleBoy";
  std::string xmlFileName="test.xml";

  std::vector<std::string> testFilesList1;
  testFilesList1.push_back("A.h");
  testFilesList1.push_back("A.cpp");
  testFilesList1.push_back("B.h");
  testFilesList1.push_back("B.cpp");
  testFilesList1.push_back("C.h");
  testFilesList1.push_back("C.cpp");
  testFilesList1.push_back("D.h");
  testFilesList1.push_back("D.cpp");
  
  eh.projectGenerator(folderpath,testName,testFilesList1);
  eh.fileGenerator(folderpath,testName);
  eh.testFilesFinder(folderpath,xmlFileName,testFilesList1);

  return 0;
}

#endif
