// XXX.cpp
//
// Jothikumar Rathinamoorthy

#include "XXX.h"




TestDriver::TestDriver(void)
{
  // initialize any test stuff here
}

TestDriver::~TestDriver(void)
{
  // deallocate test resources here
}

ITest* ITest::createTest()
{
  return new TestDriver;
}

bool TestDriver::test()
{
  
  return true;
}

