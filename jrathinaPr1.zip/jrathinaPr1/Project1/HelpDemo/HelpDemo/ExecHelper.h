#ifndef EXEC_HELPER_H
#define EXEC_HELPER_H

///////////////////////////////////////////////////////////////////////
//  ExecHelper.h  - Helps the Executive file by finding the list of  //
//  test files and supplying input to codeGenerator and fileGenerator//
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    It Helps the Executive file by finding the list of test files and 
    supplying input to codeGenerator and fileGenerator
   


    Public Interface:
    -----------------
      ExecHelper eh;                                             creating object for ExecHelper class
      eh.projectGenerator(folderpath,testName,testFilesList1);   supplying list of files for project generator
      eh.fileGenerator(folderpath,testName);                     supplying list of files for file generator
      eh.testFilesFinder(folderpath,xmlFileName,testFilesList1); finding the test files

*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /EHa /DTEST_EXEC_HELPER ExecHelper.cpp                //
//                                                           //
//  Files Required:                                          //
//    ProjectGenerator.h,ProjectGenerator.cpp,               //
//    FileGenerator.h,FileGenerator.cpp,xmlFileMgr.h,        //
//    xmlFileMgr.cpp                                         //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/

#include <string>
#include <vector>
#include "ProjectGenerator.h"
#include "FileGenerator.h"
#include "xmlFileMgr.h"

class ExecHelper
{
public:
  void projectGenerator(std::string folderpath, std::string testName, std::vector<std::string> testIncludeFiles);
  void fileGenerator(std::string folderpath, std::string testName);
  std::vector<std::string> testFilesFinder(std::string folderpath,std::string xmlFileName,std::vector<std::string> files);
};


#endif