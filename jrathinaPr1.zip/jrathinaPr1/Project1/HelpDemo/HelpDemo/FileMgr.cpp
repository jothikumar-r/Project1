///////////////////////////////////////////////////////////////////////
//  FileMgr.h  -  Process files in the test folder                   //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////


#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include "WinTools.h"
#include "FileMgr.h"
#include "XmlReader.h"

using namespace Win32Tools;

//constructor initializing the variables
FileMgr::FileMgr(int argc, char* argv[])
{
  _argc = argc;
  _argv = argv;
}

//function finding the files with the pattern in the mentioned path
FileMgr::fileSet FileMgr::FindFiles(const std::string& path, const std::string& pattern)
{
  return directory::GetFiles(path, pattern);
}


//---- test stub ---------------------------------

#ifdef TEST_FILEMGR

int main(int argc, char* argv[])
{
  // assumes path may be named by argv[1]
  // assumes patterns may be named by argv[2], argv{3}, ...

  std::string path = ".";
  std::string pattern = "*.*";
  if(argc > 1)
    path = argv[1];
  if(argc > 2)
    pattern = argv[2];

  FileMgr fm(argc, argv);
  FileMgr::fileSet fs = fm.FindFiles(path, pattern);

  int count = 2;
  while(count < argc)
  {
    pattern = argv[count++];
    FileMgr::fileSet files = fm.FindFiles(path, pattern);

    for(size_t i=0; i<files.size(); ++i)
      std::cout << "\n  " << files[i];
    std::cout << "\n\n";
  }
}
#endif
