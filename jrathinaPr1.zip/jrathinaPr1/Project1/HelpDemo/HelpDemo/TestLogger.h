#pragma once
// XXX.h
//
// Jothikumar Rathinamoorthy

#define TEST_EXPORTS
#include "ITestLogger.h"

#include <vector>
#include <string>

class TestLogger : public ITestLogger
{
public:
  TestLogger(void);
  virtual ~TestLogger(void);
  virtual void printOutput(std::vector<std::string>);
  // inherits static creational function
};