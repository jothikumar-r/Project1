#pragma once
// XXX.h
//
// Jothikumar Rathinamoorthy

#define TEST_EXPORTS
#include "ITestGenerator.h"

#include <vector>
#include <string>

class TestDataGenerator: public ITestGenerator
{
public:
  TestDataGenerator(void);
  virtual ~TestDataGenerator(void);
  virtual std::vector<std::string> getInput();
  // inherits static creational function
};
