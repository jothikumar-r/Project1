#pragma once
// TestDriver header file
//
// Jothikumar

#define TEST_EXPORTS
#include "itest.h"
#include "ITestGenerator.h"
#include "ITestLogger.h"

//include

class TestDriver : public ITest
{
public:
  TestDriver(void);
  virtual ~TestDriver(void);
  virtual bool test();
  // inherits static creational function
};
