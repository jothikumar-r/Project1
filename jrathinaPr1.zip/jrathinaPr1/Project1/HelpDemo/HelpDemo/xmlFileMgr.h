#ifndef XML_FILE_MGR_H
#define XML_FILE_MGR_H

///////////////////////////////////////////////////////////////////////
//  xmlFileMgr.h  -   Finds the presence of xml file, finds the test //
//  name and the name of the test files                              //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    It checks for the presence of the xml file in the test folder. It
    also look for the test name in the xml file and the name of the test
    files in the xml file.
   


    Public Interface:
    -----------------
      xmlFileMgr xmlFm;                               creating object of xmlFileMgr class
      xmlFm.fileExists(path,xmlFileName);             calling function to check the existence of the file
      xmlFm.FindFiles(path,xmlFileName);              calling function to find the files in the xmk file
      xmlFm.FindTestName(path,xmlFileName);           calling function to find the name of the test name in the xml file


*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /EHa /DTEST_XML_FILEMGR xmlFileMgr.cpp                //
//                                                           //
//  Files Required:                                          //
//    xmlFileMgr.h,xmlFileMgr.cpp                            //
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/


#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include "XmlReader.h"

class xmlFileMgr
{
public:
  std::vector<std::string> FindFiles(const std::string& path, const std::string& xmlFileName);
  std::string FindTestName(const std::string& path, const std::string& xmlFileName);
  bool fileExists(const std::string& path, const std::string& xmlFileName);

private:
  std::vector<std::string> filesInXml;
  std::string testName;
};


#endif


