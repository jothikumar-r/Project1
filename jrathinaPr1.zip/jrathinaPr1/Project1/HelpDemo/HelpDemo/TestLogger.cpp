#include "XXX.h"
#include <iostream>

TestLogger::TestLogger(void)
{

}

TestLogger::~TestLogger(void)
{

}

ITestLogger* ITestLogger::createTest()
{
  return new TestLogger;
}

void TestLogger::printOutput(std::vector<std::string> output)
{

}
