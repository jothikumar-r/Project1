///////////////////////////////////////////////////////////////////////
//                                                                   //
//                    Test Harness Using C++                         //
//                                                                   //
//        Project 1 : Creating a Test Generator Wizard               //
//                                                                   //
// (This wizard will be used for creating the entire Test Harness    //
// and automating the test cases based on the configurations in the  //
// XML Config File.)                                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////
//  Exec.cpp  -  Executive which controls creating test harness      //
//  wizard                                                           //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    Executive gets the name of the testfolder having the test files
    and test xml configuration file. If the user is not providing
    an xml file, it will take all the files inside the test folder as
    tested files.If the user is proving an xml file, it will check
    whether all the files in the xml file are present inside the test
    folder. If all files in the xml file are not present in the test
    folder, it will stop the execution. If all are present, it will look
    for the parent file by analyzing the dependency between the files.
    After finding the root, it has to be included in the test driver
    and the test driver is renamed to <testname>testdriver. Same for 
    Test data generator and test logger. After that, a visual studio
    project is created by includeing the tested files, interfaces such as
    ITest, ITestGenerator and ITestLogger and test driver, test data generator
    and testlogger.


    Public Interface:
    -----------------
      FileMgr fm(argc, argv);                                   creating object for FileMgr class and calling constructor with the values argc and argv
      fm.FindFiles(folderpath, pattern)                         finding the files with the pattern in the mentioned path
      directory dir;                                            creating object for Directory class
      dir.DirectoryExists(folderpath)                           checking the presence of the directory
      xmlFileMgr xmlFM;                                         creating object for XML File manager class  
      xmlFM.FindTestName(path,xmlFileName);                     Finding the test name from the xml file
      ExecHelper eh;                                            creating object for Executive helper class
      eh.testFilesFinder(folderpath,xmlFileName,files);         Finding the test files
      DependencyAnalyzer da;                                    creating object for Dependency Analyzer class
      da.findRoot(folderpath, testIncludeFiles);                finding the root file(s) 
      codeGenerator cg;                                         creating object for code generator class
      cg.fileGenerator(folderpath,testName,rootFile);           generating the test driver
      eh.fileGenerator(folderpath, testName);                   supplying list of files to generate inside the test folder
      eh.projectGenerator(folderpath,testName,testIncludeFiles);generating visual studio project having all the files

*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /Eha Exec.cpp                                         //
//                                                           //             
//  Files Required:                                          //
//    CodeGenerator.h,CodeGenerator.cpp,DependencyAnalyzer.h,//
//    DependencyAnalyzer.cpp,ExecHelper.h, ExecHelper.cpp,   //
//    FileGenerator.h,FileGenerator.cpp,fileInfo.h,          //
//    fileInfo.cpp,FileMgr.h,FileMgr.cpp,FileSstem.h,        //
//    FileSstem.cpp,GetIncludes.h,GetIncludes.cpp,           //
//    ProjectGenerator.h,ProjectGenerator.cpp,StringConversion.h,
//    StringConversion.cpp,WinTools.h,WinTools.cpp,          //
//    xmlFileMgr.h,xmlFileMgr.cpp,XmlReader.h, XmlReader.cpp //                          
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/



#include <iostream>
#include "WinTools.h"
#include "FileMgr.h"
#include "xmlFileMgr.h"
#include "DependencyAnalyzer.h"
#include "CodeGenerator.h"
#include "FileGenerator.h"
#include "ProjectGenerator.h"
#include "ExecHelper.h"

using namespace Win32Tools;

int main(int argc, char* argv[])
{
  std::string folderpath = ".";                          //initializing the variables
  std::string pattern = "*.*";
  std::string xmlFileName = "test.xml";
  std::string testName = "TestHarnessWizard";
  FileMgr fm(argc, argv);
  try{
  if(argc>1)
  {
    folderpath = argv[1];
    directory dir;
    if(!dir.DirectoryExists(folderpath))                  //checking for directory
    {
      std::cout<<"Directory not exists !";
      return 0;
    }
    std::cout << "\n  Processing files in Test Folder: " << Win32Tools::path::getFullPath(folderpath)  << std::endl;
    pattern = "*.h";
    FileMgr::fileSet files = fm.FindFiles(folderpath, pattern);         //finding files with the pattern
    pattern = "*.cpp";
    FileMgr::fileSet files1 = fm.FindFiles(folderpath, pattern);
    
    for(size_t i=0;i<files1.size();i++)
      files.push_back(files1[i]);

    for(size_t i=0; i<files.size(); ++i)
      std::cout << "\n  " << files[i];
    std::vector<std::string> testIncludeFiles, rootFile;
    
    ExecHelper eh;                                                          //creating objects for classes for calling the functions inside those classes
    xmlFileMgr xmlFM;
    
    testName = xmlFM.FindTestName(folderpath,xmlFileName);                  //getting testname from the xml file
    testIncludeFiles = eh.testFilesFinder(folderpath,xmlFileName,files);    //getting test include files
    
    DependencyAnalyzer da;
    rootFile = da.findRoot(folderpath, testIncludeFiles);                   //gettin the root and printing the root file
    
    std::cout<<"\n\n Root File:";
    for(size_t i=0; i<rootFile.size(); ++i)
      std::cout << "\n  " << rootFile[i];
    std::cout << "\n\n";
    
    codeGenerator cg; 
    cg.fileGenerator(folderpath,testName,rootFile);                         //generating the testdriver package
    eh.fileGenerator(folderpath, testName);                                 //generating other files in the test folder
    eh.projectGenerator(folderpath,testName,testIncludeFiles);              //generating the visual studio project
    std::cout<<"Visual Studio Project is created in the folder: jrathinaPr1\\Testfolder";
  }
    else
      std::cout<<"\nPlease Provide the path of the test folder !";
  }
  catch(char *ex)                                                           //catching the exception
  {
    std::cout<<"\n"<<ex;
  }
}

