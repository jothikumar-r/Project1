// Main.cpp
//
// Jothikumar Rathinamoorthy

#include <iostream>
#include "ITest.h"

int main()
{
  std::cout << "\n  Tokenizer - Test Harness Wizard Demo";
  std::cout << "\n =====================================\n";

  ITest* pTest = ITest::createTest();
  if(pTest->test())
    std::cout << "\n All test cases passed\n\n";
  else
    std::cout << "\n All or Some test cases failed\n\n";
    
    return 0;
}
