#ifndef DEP_ANAL_H
#define DEP_ANAL_H

///////////////////////////////////////////////////////////////////////
//  DependencyAnalyzer.h  -   Finds the parent(root) file(s) from the//
//  list of test files in test folder                                //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    It gets the list of files from the executive and finds the root file(s)
   


    Public Interface:
    -----------------
      DependencyAnalyzer da;                        creating object of DependencyAnalyzer class
      da.findRoot(path,testFilesList1);             calling findRoot to find the root file(s).

*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /EHa /DTEST_DEP_ANAL DependencyAnalyzer.cpp           //
//                                                           //
//  Files Required:                                          //
//    DependencyAnalyzer.h,DependencyAnalyzer.cpp            //
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/


#include <vector>
#include <string>


class DependencyAnalyzer
{

public:
  
  std::vector<std::string> findRoot(const std::string&, std::vector<std::string>);
  

private:
  bool fileExists(const std::string& filePath);
  std::vector<std::string> rootList;
  std::vector<std::vector<std::string>> dependencyAnalyzerHelper(std::vector<std::string> files, std::vector<std::vector<std::string>> includeFileTree);
  void includeFileChecker(std::vector<std::vector<std::string>> &includeFileTree,std::vector<std::vector<std::string>> &headerFileMap);
};


#endif