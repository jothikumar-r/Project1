///////////////////////////////////////////////////////////////////////
//  DependencyAnalyzer.cpp-   Finds the parent(root) file(s) from the//
//  list of test files in test folder                                //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////

#include "DependencyAnalyzer.h"
#include "../FileSystemDemo/FileSystem.h"
#include "GetIncludes.h"

#include <iostream>
#include <fstream>

using namespace WinTools_Extracts;


//function to find the root file from a list of test files
std::vector<std::string> DependencyAnalyzer::findRoot(const std::string& path, std::vector<std::string> files)
{
  FileHandler fh;
  std::string filePath;
  std::vector<std::vector<std::string>> includeFileTree;
  std::vector<std::string> includeFiles;
  includeFileTree.resize(files.size());

  for(size_t i=0; i<files.size(); ++i)
  {
    std::cout << "\n\n  Processing file " << fh.getFileName(files[i]);
    filePath = path + "\\" + files[i];
    includeFileTree[i].resize(1);
    includeFileTree[i][0]=files[i];

    File f(filePath,File::in);
    while(f.isGood())                                                           //getting the included header files
    {
      std::string line = f.getLine();
      if(line.size() > 0 && line[0] == '#')
      {
        std::string temp = Includes::getIncludedFileSpec(line, Includes::local);
        if(temp.size() > 0)
        {
          FileHandler fh;
          std::cout << "\n      Included files are: " << fh.getFileName(temp);
          includeFiles.push_back(fh.getFileName(temp));
        }
      }
    }
    for(size_t k=0;k<includeFiles.size();k++)
    {
      if(includeFiles[k]=="")
        continue;
      includeFileTree[i].push_back(includeFiles[k]);
    }
    includeFiles.clear();
  }
  
  std::vector<std::vector<std::string>> headerFileMap;
  headerFileMap = dependencyAnalyzerHelper(files,includeFileTree);

  for(size_t i=0;i<headerFileMap.size();i++)                      //traversiing through the list of files to find the root
  {
    if(headerFileMap[i][1]=="not_included")
      rootList.push_back(headerFileMap[i][0]);
  }
  return rootList;
}


//helper function to support finding the root file
std::vector<std::vector<std::string>> DependencyAnalyzer::dependencyAnalyzerHelper(std::vector<std::string> files, std::vector<std::vector<std::string>> includeFileTree)
{
  std::vector<std::vector<std::string>> headerFileMap;
  std::vector<std::string> headerFileList,rootList;
  for(size_t i=0;i<files.size();i++)
  {
    if((files[i].find(".h"))!=-1)
      headerFileList.push_back(files[i]);
  }
  headerFileMap.resize(headerFileList.size());
  for(size_t i=0;i<headerFileList.size();i++)             //traversing through the list of files to find the root
  {
    headerFileMap[i].resize(2);
    headerFileMap[i][0] = headerFileList[i];
    headerFileMap[i][1] = "not_included";
  }
 includeFileChecker(includeFileTree, headerFileMap);
 return headerFileMap;
}


//checking the include files
void DependencyAnalyzer::includeFileChecker(std::vector<std::vector<std::string>> &includeFileTree,std::vector<std::vector<std::string>> &headerFileMap)
{
  for(size_t i=0;i<includeFileTree.size();i++)
  {
    for(size_t j=1;j<includeFileTree[i].size();j++)
    {
      if((includeFileTree[i][0].find(".cpp"))!=-1)           //Checking whether the .cpp and .h belong to the same package
      {
        std::string filename = includeFileTree[i][0].substr(0,includeFileTree[i][0].find(".cpp"));
        std::string inclFilename = includeFileTree[i][j].substr(0,includeFileTree[i][j].find(".h"));
        if(filename == inclFilename)
          continue;
      }
        for(size_t k=0;k<headerFileMap.size();k++)
        {
          if(includeFileTree[i][j]==headerFileMap[k][0])
            headerFileMap[k][1] = "included";
        }
      }
  }
}


//<------------------------------------ test stub -------------------------------------------------

#ifdef TEST_DEP_ANAL

#include <iostream>
#include <vector>

int main()
{
  
  DependencyAnalyzer da;
  
  std::string path="..//..//testfolder";
  std::vector<std::string> testFilesList1;
  std::vector<std::string> root;

  testFilesList1.push_back("A.h");
  testFilesList1.push_back("A.cpp");
  testFilesList1.push_back("B.h");
  testFilesList1.push_back("B.cpp");
  testFilesList1.push_back("C.h");
  testFilesList1.push_back("C.cpp");
  testFilesList1.push_back("D.h");
  testFilesList1.push_back("D.cpp");

  std::cout<<"Demonstrating Dependency Analyzer\n";
  std::cout<<"=================================\n";

  root = da.findRoot(path,testFilesList1);

  std::cout<<"\n\n\nRoot Files: \n";
  for(size_t i=0;i<root.size();i++)
    std::cout<<root[i]<<std::endl;

  return 0;
}

#endif