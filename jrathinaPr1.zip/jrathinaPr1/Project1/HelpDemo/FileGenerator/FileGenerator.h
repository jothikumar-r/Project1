#ifndef FILE_GEN_H
#define FILE_GEN_H

///////////////////////////////////////////////////////////////////////
//  FileGenerator.h  -  generates test data generator and test logger//
//  in test folder                                                   //
//  ver 1.0                                                          //
//  Language:      Visual C++, Visual Studio 2010, SP1               //
//  Platform:      Dell Inspiron, Win 7 Home Premium, SP1            //
//  Application:   OOD Project 1, Feb 2012                           //
//  Author:        Jothikumar Rathinamoorthy, Syracuse University    //
//                 (315) 420-0053, jrathina@syr.edu                  //
///////////////////////////////////////////////////////////////////////
/*
    Executive Operations:
    --------------------------
    It generates test data generator and test logger in the test folder.
   


    Public Interface:
    -----------------
      FileGenerator fg;                             creating object of FileGenerator class
      fg.copyFiles("C:\\", m_copyFilesList);        calling copyfiles function

*/
///////////////////////////////////////////////////////////////
//                      maintenance page                     //
///////////////////////////////////////////////////////////////
//  Build Process                                            //
//  cl /EHa /DTEST_FILE_GEN FileGenerator.cpp                //
//                                                           //
//  Files Required:                                          //
//    FileGenerator.h,FileGenerator.cpp                      //
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////
/*
    Maintenance History
    ===================
    ver 1.0 : 09 Feb 12
      - first release
*/


#include <string>
#include <fstream>
#include <vector>


class FileGenerator
{
public:
  void copyFiles(const std::string& path, std::vector<std::string> copyFilesList);
  void datagenLogFileGenerator(const std::string& path, const std::string& testName);

private:

};

#endif

