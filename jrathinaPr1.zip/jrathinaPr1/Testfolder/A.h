#ifndef A_H
#define A_H


#include "B.h"

#endif