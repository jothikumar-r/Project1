#ifndef B_H
#define B_H

#include "C.h"
#include "D.h"

#endif
