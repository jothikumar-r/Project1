#pragma once

// TestTokenizerTestDataGenerator.h 
// Header file having function declarations
// It performs reading the input from text files based on the test case number
// and sends input and the expected output to the test driver
// Jothikumar Rathinamoorthy

#define TEST_EXPORTS
#include "ITestGenerator.h"

#include <vector>
#include <string>
#include <fstream>
#include <istream>

class TestDataGenerator: public ITestGenerator
{
public:
  TestDataGenerator(void);
  virtual ~TestDataGenerator(void);
  virtual std::vector<std::string> getInput(int testCaseIndex);
  // inherits static creational function

private:
  std::string getTestInput(std::string filePath);
  std::vector<std::string> getExpectedOutput(std::string filePath);

};

