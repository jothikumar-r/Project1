#pragma once

// ITest.h - Interface file having only the function names
// Classes deriving ITest class will implement the functions
// Executive will use this interface to call the functions in the dll or library files
// Jothikumar Rathinamoorthy


#ifdef TEST_EXPORTS
#define TEST_API __declspec(dllexport)
#else
#define TEST_API __declspec(dllimport)
#endif

class TEST_API ITest
{
public:
  virtual ~ITest(void) {}
  static ITest* createTest();
  virtual bool test()=0;
};


