#pragma once

// TestTokenizerTestDriver header file
// Header file having function declarations
// It gets the input and expected output from the Test Data Generator and 
// sends the input to the tokenizer and compares the actual output with 
// the expected output and sends the result to the test logger
// Jothikumar

#define TEST_EXPORTS
#include "itest.h"
#include "ITestGenerator.h"
#include "ITestLogger.h"

#include "Tokenizer.h"

class TestDriver : public ITest
{
public:
  TestDriver(void);
  virtual ~TestDriver(void);
  virtual bool test();
private:
  bool test1();
  bool test2();
  bool test3();
  bool resultsComparer(std::string testInput, std::vector<std::string> expOpStr);
  // inherits static creational function
};


