#include "TestTokenizerTestDataGenerator.h"

// TestTokenizerTestDataGenerator.cpp
// Implementation file having function definitions for the functions declared in TestTokenizerTestDataGenerator.h
// It performs reading the input from text files based on the test case number
// and sends input and the expected output to the test driver
// Jothikumar Rathinamoorthy

//constructor
TestDataGenerator::TestDataGenerator(void)
{

}

//destructor
TestDataGenerator::~TestDataGenerator(void)
{

}

//Object Factory function
ITestGenerator* ITestGenerator::createTest()
{
  return new TestDataGenerator;
}

//function for getting input based on test case number
std::vector<std::string> TestDataGenerator::getInput(int testCaseIndex)
{
  std::string testInput;
  std::vector<std::string> expectedOutput;

  switch(testCaseIndex)
  {
  case 1:
    testInput = getTestInput("testinput1.txt");
    expectedOutput = getExpectedOutput("expectedoutput1.txt");
    break;

  case 2:
    testInput = getTestInput("testinput2.txt");
    expectedOutput = getExpectedOutput("expectedoutput2.txt");
    break;
  
  case 3:
    testInput = getTestInput("testinput3.txt");
    expectedOutput = getExpectedOutput("expectedoutput3.txt");
    break;

  case 4:
    testInput = getTestInput("testinput4.txt");
    expectedOutput = getExpectedOutput("expectedoutput4.txt");
    break;
  }

  expectedOutput.push_back(testInput);
  return expectedOutput;
}

//reading test case input
std::string TestDataGenerator::getTestInput(std::string filePath)
{
  std::string line="";
  std::ifstream myfile (filePath);
  if (myfile.is_open())                           
  {
    while (myfile.good())
    {
      std::getline (myfile,line);
      break;
    }
    myfile.close();
  }
  return line;
}

//reading test case expected output
std::vector<std::string> TestDataGenerator::getExpectedOutput(std::string filePath)
{
  std::vector<std::string> expOpStr;
  std::string line="";
  std::ifstream myfile1 (filePath);
  if (myfile1.is_open())                           
  {
    while (myfile1.good())
    {
      std::getline (myfile1,line);
      expOpStr.push_back(line);
    }
    myfile1.close();
  }
  return expOpStr;
}
