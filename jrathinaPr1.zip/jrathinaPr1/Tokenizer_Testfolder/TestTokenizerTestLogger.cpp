#include "TestTokenizerTestLogger.h"
#include <iostream>

// TestTokenizerTestLogger.cpp
// Implementation file having function definition
// It gets the output from the TestTokenizerTestDriver and 
// prints the output in the console window
// Jothikumar Rathinamoorthy

//constructor
TestLogger::TestLogger(void)
{

}

//destructor
TestLogger::~TestLogger(void)
{

}

//object factory function
ITestLogger* ITestLogger::createTest()
{
  return new TestLogger;
}

//function for printing the output in the console window
void TestLogger::printOutput(std::vector<std::string> output)
{
  for(size_t i=0;i<output.size();i++)
    std::cout<<"\n"<<output[i];
}

