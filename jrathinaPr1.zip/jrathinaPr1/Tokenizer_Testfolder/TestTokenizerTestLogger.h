#pragma once

// TestTokenizerTestLogger.h
// Header file having function declarations
// It gets the output from the TestTokenizerTestDriver and 
// prints the output in the console window
// Jothikumar Rathinamoorthy

#define TEST_EXPORTS
#include "ITestLogger.h"

#include <vector>
#include <string>

class TestLogger : public ITestLogger
{
public:
  TestLogger(void);
  virtual ~TestLogger(void);
  virtual void printOutput(std::vector<std::string>);
  // inherits static creational function
};
