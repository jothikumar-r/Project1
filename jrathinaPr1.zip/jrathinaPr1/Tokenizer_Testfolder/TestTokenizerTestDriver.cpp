
// TestTokenizerTestDriver implementation file
// Implementation file having function definitions
// It gets the input and expected output from the Test Data Generator and 
// sends the input to the tokenizer and compares the actual output with 
// the expected output and sends the result to the test logger
// Jothikumar


#include "TestTokenizerTestDriver.h"
#include <iostream>
#include <fstream>

//constructor
TestDriver::TestDriver(void)
{
  // initialize any test stuff here
}


//destructor
TestDriver::~TestDriver(void)
{
  // deallocate test resources here
}

//object factory function
ITest* ITest::createTest()
{
  return new TestDriver;
}

//test method which initializes the testing process by performing tests in different test cases
bool TestDriver::test()
{
  if(test1() && test2() && test3())
    return true;
  else
    return false;
}

//function for comparing the actual output with the expected output
bool TestDriver::resultsComparer(std::string testInput, std::vector<std::string> expOpStr)
{
  Toker t_fromStr(testInput, false);
  std::vector<std::string> testInputVect;
  bool chkFlg=true;
  std::string tok;
  do
  {
    tok = t_fromStr.getTok();
    testInputVect.push_back(tok);
  } while(tok != "");
  for(size_t i=0;i<expOpStr.size();i++)
  {
    if(expOpStr[i]!=testInputVect[i])           //Comparing Actual output with the expected output
    {
      chkFlg=false;
      break;
    }
  }
  return chkFlg;
}

//test case1
bool TestDriver::test1()
{
  ITestGenerator* pTestGenerator = ITestGenerator::createTest();
  std::vector<std::string> expOpStr;
  expOpStr = pTestGenerator->getInput(1);
  std::string testInput="";
  testInput = expOpStr[expOpStr.size()-1];
  expOpStr.pop_back();
  bool chkFlg;
  std::vector<std::string> output;

  chkFlg = resultsComparer(testInput, expOpStr);
  ITestLogger* pTestLogger = ITestLogger::createTest();
  
  if(chkFlg==true)
  {
    output.push_back("Test Case 1 ------  Pass");
    pTestLogger->printOutput(output);
  }
  else
  {
    output.push_back("Test Case 1 ------  Fail");
    pTestLogger->printOutput(output);
  }
  return chkFlg;
}

//test case2
bool TestDriver::test2()
{
  ITestGenerator* pTestGenerator = ITestGenerator::createTest();
  std::vector<std::string> expOpStr;
  expOpStr = pTestGenerator->getInput(2);
  std::string testInput="";
  testInput = expOpStr[expOpStr.size()-1];
  expOpStr.pop_back();
  bool chkFlg;
  std::vector<std::string> output;

  chkFlg = resultsComparer(testInput, expOpStr);
  ITestLogger* pTestLogger = ITestLogger::createTest();
  
  if(chkFlg==true)
  {
    output.push_back("Test Case 2 ------  Pass");
    pTestLogger->printOutput(output);
  }
  else
  {
    output.push_back("Test Case 2 ------  Fail");
    pTestLogger->printOutput(output);
  }
  return chkFlg;
}

//test case3
bool TestDriver::test3()
{
  ITestGenerator* pTestGenerator = ITestGenerator::createTest();
  std::vector<std::string> expOpStr;
  expOpStr = pTestGenerator->getInput(3);
  std::string testInput="";;
  testInput = expOpStr[expOpStr.size()-1];
  expOpStr.pop_back();
  bool chkFlg;
  std::vector<std::string> output;

  chkFlg = resultsComparer(testInput, expOpStr);
  ITestLogger* pTestLogger = ITestLogger::createTest();
  
  if(chkFlg==true)
  {
    output.push_back("Test Case 3 ------  Pass");
    pTestLogger->printOutput(output);
  }
  else
  {
    output.push_back("Test Case 3 ------  Fail");
    pTestLogger->printOutput(output);
  }
  return chkFlg;
}












