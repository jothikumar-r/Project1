#pragma once

// ITestGenerator.h - Interface file having only the function names
// Classes deriving ITestGenerator class will implement the functions
// TokenizerTestDriver will use this interface to call the functions in the dll or library files
// Jothikumar Rathinamoorthy

#ifdef TEST_EXPORTS
#define TEST_API __declspec(dllexport)
#else
#define TEST_API __declspec(dllimport)
#endif

#include <vector>
#include <string>

class TEST_API ITestGenerator
{
public:
  virtual ~ITestGenerator(void) {}
  static ITestGenerator* createTest();
  virtual std::vector<std::string> getInput(int)=0;
};

