#pragma once

// ITestLogger.h - Interface file having only the function names
// Classes deriving ITestLogger class will implement the functions
// TokenizerTestDriver will use this interface to call the functions in the dll or library files
// Jothikumar Rathinamoorthy

#ifdef TEST_EXPORTS
#define TEST_API __declspec(dllexport)
#else
#define TEST_API __declspec(dllimport)
#endif

#include <vector>
#include <string>

class TEST_API ITestLogger
{
public:
  virtual ~ITestLogger(void) {}
  static ITestLogger* createTest();
  virtual void printOutput(std::vector<std::string>)=0;
};

